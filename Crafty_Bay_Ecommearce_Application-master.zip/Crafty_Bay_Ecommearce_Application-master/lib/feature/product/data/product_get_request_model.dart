class ProductGetRequestModel {
  String? category='';
  String? tag ='';
  ProductGetRequestModel({this.category, this.tag});
}