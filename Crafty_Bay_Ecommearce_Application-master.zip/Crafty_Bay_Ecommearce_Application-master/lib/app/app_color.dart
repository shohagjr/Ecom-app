import 'package:flutter/material.dart';

class AppColors {
  static const Color themeColor = Color(0xFF07ADAE);
}