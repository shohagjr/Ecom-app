class AppConfigs {
  static const String baseUrl = '';
  static const String currentAppVersion = '1.0.1';
}