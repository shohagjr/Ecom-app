package nahid.info.bd.crafty_bay

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
